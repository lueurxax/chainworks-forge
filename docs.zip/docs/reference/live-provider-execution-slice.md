# Live Provider Execution Slice

This document is the permanent reference for the implemented live proposal-loop slice.

It describes the current fixture-backed live runtime contract, the app surfaces that make the slice usable, the artifact and safety guarantees, and the boundary between the implemented slice and later follow-on work.

## Status

- State: implemented as ACP-only live execution baseline
- Scope owner: current app runtime and UI shell
- Backing workflow: `examples/workflows/proposal-loop-live.yaml`
- Live transport: runtime-profile-selected `RuntimeTransportProtocol` adapter or deterministic ACP fixture transport

Current repo-backed ACP families in this slice are:

- `claude_agent_acp`
- `gemini_cli_acp`

## Related Docs

- [runtime-contract.md](runtime-contract.md)
- [workspace-isolation-risk.md](workspace-isolation-risk.md)
- [architecture-decisions.md](architecture-decisions.md)
- [workflow-execution-engine.md](workflow-execution-engine.md)
- [acp-runtime-transport.md](acp-runtime-transport.md)
- [skill-resolution-and-runtime-integration.md](skill-resolution-and-runtime-integration.md)
- [per-agent-mcp-policy-and-runtime-validation.md](per-agent-mcp-policy-and-runtime-validation.md)

## 1. Purpose

The live provider execution slice is the first app-facing non-simulated execution path in Chainworks Forge.

Its job is narrow on purpose:

- run the proposal loop through the same execution engine the rest of the product uses
- enforce explicit workspace and safety rules at runtime
- persist durable proposal, review, summary, and receipt artifacts
- pause at approval with enough context for a human decision
- resume safely after interruption

This slice proves the control-plane model without introducing writable repo side effects.

## 2. Scope Boundary

### In scope

- live-mode execution for the proposal loop only
- `RuntimeAgentExecutor`, `RuntimeSessionBridge`, runtime adapters, and `ExecutionEventBridge`
- fixture-backed live transport used by the app and tests
- read-only/diagnostic Start Run, Run Progress, approval, and artifact-inspection surfaces (per P031-r18)
- durable transcript, receipt, proposal, review, and summary artifacts
- fail-closed read-only launch policy
- structured artifact validation before success and transition evaluation
- safe resume for waiting-approval and other non-destructive states

### Out of scope

- writable implementation worktrees
- git, release, or publish side effects
- code-writing stages
- second-wave runtime expansion beyond the currently implemented adapter families

## 3. Runtime Shape

```text
SwiftUI App
  -> ExecutionService
    -> WorkflowOrchestrator
      -> RuntimeAgentExecutor
        -> RuntimeSessionBridge
          -> selected RuntimeTransportProtocol adapter
      -> ArtifactManager / ArtifactStorage
      -> Approval flow
```

The app remains the control plane. ACP adapters are execution substrates, not the source of truth.

Control-plane responsibilities stay in app code:

- run lifecycle
- workflow transitions
- approval state
- artifact indexing
- resume decisions
- workspace isolation
- failure policy

Provider-facing responsibilities stay in the live executor path:

- session lifecycle
- prompt packet construction
- streaming events
- tool execution
- final model output

## 4. Runtime Contract

### 4.1 One `AgentExecution` equals one live session

Every live `AgentExecution` gets its own isolated session.

That means:

- no session reuse across agents
- no session reuse across iterations
- no hidden provider memory dependency
- no cross-run conversational carry-over

The only durable explanation for an output is the stored inputs, packet, artifacts, and metadata.

### 4.2 Explicit workspace, never implicit cwd

Every live execution is bound to an explicit `RunWorkspace`.

For this slice:

- `workspaceRoot` is run-scoped
- `artifactRoot` is inside that workspace
- `worktreeRoot` remains `nil`
- repo writes are forbidden
- no execution may rely on implicit cwd

This contract is enforced both in request construction and in downstream path guards.

### 4.3 Fail-closed read-only policy

Live launch is allowed only when the backend acknowledges the required read-only execution policy.

The launch packet carries:

- run and stage identity
- workspace roots
- resolved permission policy
- explicit no-git / no-release / no-repo-write rules
- the acknowledgement field required for launch

If acknowledgement is absent, launch fails before the first live stage starts.

### 4.4 Structured artifact validation before transitions

File existence alone is not enough for success.

The runtime requires:

- declared required outputs to exist
- artifacts to be persisted before success is recorded
- reviewer and aggregate-review JSON to pass structural validation
- malformed structured artifacts to fail the stage before transition evaluation

The proposal loop therefore consumes validated structured review artifacts, not opportunistic JSON reads.

## 5. Live Proposal Workflow

The live slice is intentionally narrow and runs only the proposal loop workflow:

- `lead_orchestrator`
- `proposal_writer`
- `proposal_reviewer_product_owner`
- `proposal_reviewer_ux`
- `proposal_reviewer_ui`
- `proposal_reviewer_architect`

Primary workflow file:

- `examples/workflows/proposal-loop-live.yaml`

Expected primary outputs:

| Agent | Primary artifact |
|---|---|
| `proposal_writer` | `proposal_current.md` |
| `proposal_reviewer_product_owner` | `proposal_review_po.json` |
| `proposal_reviewer_ux` | `proposal_review_ux.json` |
| `proposal_reviewer_ui` | `proposal_review_ui.json` |
| `proposal_reviewer_architect` | `proposal_review_arch.json` |
| aggregate orchestrator step | `proposal_review_summary.json` |
| refinement pass | `proposal_revision_summary.json` |

Approval pauses the run at a stable decision point and resumes toward a stable inspectable outcome.

## 6. Persisted Metadata and Artifacts

The live slice persists both user-facing outputs and provider-facing execution traces.

Key `AgentExecution` metadata includes:

- `providerSessionID`
- `providerRequestID`
- `transcriptArtifactPath`
- `resolvedBackendProfileID`
- `consumedInputArtifactNamesJSON`

Live artifact classes include:

- proposal drafts
- reviewer JSON
- aggregate review summary
- refinement summary
- raw execution transcript
- structured receipt
- provider error payload, when present

The point is to make a live run inspectable after the fact without relying on hidden session state.

## 7. App Surfaces

### 7.1 Start Run

The Start Run surface (Diagnostic-only placeholder in P031) exposes:

- workflow selection
- simulated vs live mode
- resolved live-agent summary
- safety framing in product language
- explicit missing-runtime guidance when live mode cannot start
- **diagnostic identifiers** for execution via external workflows (CLI / MCP)

### 7.2 Run Progress

The live run surface (GraphQL read-only in P031) keeps the important state above the fold:

- current phase
- live agent activity
- approval state (Diagnostic-only)
- decision context
- spend or explicit unavailable state
- shortcuts to the latest proposal, review summary, and receipt artifacts

### 7.3 Approval and artifact inspection

At approval time, the operator can inspect (Read-only) :

- current proposal draft
- latest review summary
- latest refinement summary
- transcript / receipt artifacts

The artifact inspector renders both user-facing markdown and raw structured/provider-facing outputs.

### 7.4 Resume

Waiting-approval state is restored on relaunch as a diagnostic decision point.

The live slice is allowed to resume only for safe interrupted states. Ambiguous or partial provider executions must block or fail clearly rather than auto-resume silently.

## 8. Source Anchors

Primary implementation files:

- `Chainworks Forge/Engine/FixtureACPTransport.swift`
- `Chainworks Forge/Engine/RuntimeSessionBridge.swift`
- `Chainworks Forge/Engine/RuntimeAgentExecutor.swift`
- `Chainworks Forge/Engine/ExecutionEventBridge.swift`
- `Chainworks Forge/Engine/ExecutionReceiptBuilder.swift`
- `Chainworks Forge/Engine/ExecutionService.swift`
- `Chainworks Forge/Engine/WorkflowOrchestrator.swift`
- `Chainworks Forge/Engine/ResumeManager.swift`
- `Chainworks Forge/Views/IdeaListView.swift`
- `Chainworks Forge/Models/AgentExecution.swift`

Primary verification files:

- `Chainworks ForgeTests/RuntimeAgentExecutorTests.swift`
- `Chainworks ForgeTests/RuntimeSessionBridgeTests.swift`
- `Chainworks ForgeTests/LiveProposalWorkflowTests.swift`
- `Chainworks ForgeTests/EndToEndTests.swift`
- `Chainworks ForgeTests/OrchestratorTests.swift`
- `Chainworks ForgeTests/ResumeManagerTests.swift`
- `Chainworks ForgeTests/WorkspaceIsolationTests.swift`
- `Chainworks ForgeUITests/Chainworks_ForgeUITests.swift`

## 9. Verification Standard

The live slice is proven at two levels:

**Fixture-backed proof:**
- diagnostic Start Run placeholder is reachable
- Run progress, approval, and stable outcome are reachable
- Artifact inspector opens proposal and receipt-style artifacts
- At least one non-happy path is proven
- Waiting-approval restore is proven on relaunch

**Current verification baseline:**
- focused live/runtime slices remain covered by repository test gates and subsystem suites
- same-tree approved-host `full` is green on the current baseline
- adapter-specific details now live in the transport references instead of a separate proposal trail

## 10. Follow-On Boundary

This document covers the implemented live runtime contract for the proposal loop.

The transport layer supports ACP-native execution and deterministic ACP fixtures. Later operator-shell, provider-settings, and delivery-slice work builds on top of this baseline rather than redefining it.
