# Proposal 051 Dependency Audit (Pre-scheduling)

Status: **required before `p051-scaffold` scheduling**
Date: 2026-04-25
Owner: Chainworks operator planning

## Artifact purpose
The rows below resolve P051 dependency gating and sequencing before implementation starts. Each row includes a concrete canonical artifact link, owner, current gate/status, remaining gaps, and explicit parallel-vs-sequential decision.

## Required dependency table

## PR1 explicit narrow exception (applies only to P051 PR1)

PR1 may proceed while P025/P026 are missing only under this scope:
- Source-of-truth reconciliation and static `p051-scaffold` hardening.
- Non-runtime-control changes that do not add/modify Xcode broker process execution, shim dispatch/socket execution, lease lifecycle behavior, or durable Xcode-observation persistence semantics.
- Code-path work that does not reduce the isolation of non-Xcode workflows.

Any PR1 work outside this scope is blocked until canonical P025/P026 evidence is recovered.

| Proposal | Canonical artifact (checked-in) | Owner | Gate / status | Remaining gaps | Parallel-vs-sequential decision | Blocking threshold |
|---|---|---|---|---|---|---|
| P025 | _Not checked in_ (no `docs/proposals/025-*` file found) | Unclear (artifact missing in checked-in proposal tree) | **Missing canonical artifact** | Cannot verify readiness without a durable contract | **Blocked** (must locate or satisfy PR1 narrow scope) | Blocks P051 scaffold scheduling until resolved |
| P026 | _Not checked in_ (no `docs/proposals/026-*` file found) | Unclear (artifact missing in checked-in proposal tree) | **Missing canonical artifact** | Cannot verify readiness without a durable contract | **Blocked** (must locate or satisfy PR1 narrow scope) | Blocks P051 scaffold scheduling until resolved |
| P029 | `docs/reference/mcp-northbound-control-plane-server.md` | Control-plane auth/runtime authors | **Stable implemented reference** | Verify whether new Xcode broker MCP/GraphQL call patterns require any follow-up security-owner exceptions | **Parallel** with P051 prep once command-journal and call-surface review is attached in this audit | Does not block if the review confirms contract surfaces are current |
| P037 | `docs/proposals/037-acp-execution-supervision-and-idle-watchdog.md` (Draft) | Codex | **Draft** | Core execution supervision behavior is not yet finalized in this proposal; scheduling should treat P051 as dependent on watchdog readiness for any production-like rollout assumptions | **Sequential** for rollout assumptions; some scaffolding can proceed in parallel only if evidence shows no direct contract conflict | Blocks broad `shim_enforced`/release rollout until readiness is confirmed |
| P049 | `docs/proposals/049-context-strategy-management-mcp-tools.md` (Draft) | Andrey Khasanov | **Draft** | Context strategy controls are not yet implemented, leaving a gap for adaptive budget-driven run behavior during future operator routing | **Sequential** for rollout assumptions; allow scaffolding if scope is narrowed to fixed strategy profile assumptions only | May block production rollout evidence for adaptive operators; can continue scaffold on fixed defaults |

## Audit status

- `P025` / `P026`: **hard blockers** until a canonical artifact is recovered or PR1 narrow scope is explicitly approved and all scoped-deliverables above are satisfied.\
- `P029`: **must pass** with explicit call-surface verification before broad rollout states (`shim_enforced`).\
- `P037` / `P049`: can be parallelized only for isolated P051 scaffolding if no shared release-goal assumptions are taken; otherwise treated as sequencing dependencies for rollout readiness.

## P029 call-surface verification evidence

| check | status | owner | location |
|---|---|---|---|
| `xcode_mcp` call/response shape in ACP HTTP transport | **Pending** | control-plane auth/runtime | `docs/reference/mcp-northbound-control-plane-server.md` + `docs/proposals/051-shared-xcode-mcp-bridge-pool.review/http-streaming-feasibility.md` |
| `GraphQL::reports.get` exposure for `xcode_broker_health` and observation streams | **Pending** | API contract owner | `docs/reference/mcp-northbound-control-plane-server.md` |
| `mcpbridge` command-journal path and broker failure handling | **Pending** | runtime platform owner | `control-plane` command-journal evidence package for P051 scaffold |

This evidence package is required before broad `shim_enforced` rollout.
